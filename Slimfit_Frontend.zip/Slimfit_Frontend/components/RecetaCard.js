import React from "react";
import { StyleSheet, Text, View } from 'react-native'
const RecetaCard = (props) => {
    return(
        <View style={{
            backgroundColor:"#ff0000",
            height: "100%",
            width: "100%"
        }}>
            <Text style={{
                fontSize:"36",
                color:"#000000"
            }}>
                {props.apodo}
                {props.nombre}
            </Text>
        </View>
    )
}
export default RecetaCard